import asyncio
from typing import Dict, Optional


class A2AMessageBus:
    """Handles message routing between agents"""

    def __init__(self):
        self.subscribers: Dict[str, asyncio.Queue] = {}
        self.pending_responses: Dict[str, asyncio.Future] = {}

    async def publish(self, message: Dict) -> bool:
        """Publish message to recipient"""
        recipient = message.get("recipient_agent_id")
        if recipient in self.subscribers:
            await self.subscribers[recipient].put(message)
            return True
        return False

    async def subscribe(self, agent_id: str, queue: asyncio.Queue):
        """Subscribe an agent to receive messages"""
        self.subscribers[agent_id] = queue

    async def unsubscribe(self, agent_id: str):
        """Unsubscribe an agent"""
        if agent_id in self.subscribers:
            del self.subscribers[agent_id]

    async def send_and_wait(
        self,
        message: Dict,
        timeout: int = 30
    ) -> Optional[Dict]:
        """Send message and wait for response"""
        message_id = message.get("message_id")
        response_future = asyncio.Future()
        self.pending_responses[message_id] = response_future

        # Ensure recipient exists before waiting
        published = await self.publish(message)
        if not published:
            del self.pending_responses[message_id]
            raise ValueError(f"Recipient not subscribed: {message.get('recipient_agent_id')}")

        try:
            response = await asyncio.wait_for(response_future, timeout=timeout)
            return response
        except asyncio.TimeoutError:
            if message_id in self.pending_responses:
                del self.pending_responses[message_id]
            raise TimeoutError(f"No response for message {message_id}")

    def complete_request(self, in_response_to: str, response: Dict):
        """Mark a request as completed with a response"""
        if in_response_to in self.pending_responses:
            future = self.pending_responses[in_response_to]
            if not future.done():
                future.set_result(response)
            del self.pending_responses[in_response_to]


