from datetime import datetime
from typing import Dict, List, Optional


class AgentRegistry:
    """Central registry for agent discovery and capability management"""

    def __init__(self):
        self.agents: Dict[str, Dict] = {}
        self.capabilities_index: Dict[str, List[str]] = {}

    async def register_agent(
        self,
        agent_id: str,
        capabilities: List[str],
        endpoint: str = "local"
    ) -> bool:
        """Register an agent with its capabilities"""
        self.agents[agent_id] = {
            "capabilities": capabilities,
            "endpoint": endpoint,
            "status": "active",
            "last_heartbeat": datetime.now()
        }

        # Index capabilities for fast lookup
        for capability in capabilities:
            if capability not in self.capabilities_index:
                self.capabilities_index[capability] = []
            if agent_id not in self.capabilities_index[capability]:
                self.capabilities_index[capability].append(agent_id)

        return True

    async def find_agents_by_capability(self, capability: str) -> List[str]:
        """Find all agents that can perform a specific capability"""
        return self.capabilities_index.get(capability, [])

    async def get_agent_info(self, agent_id: str) -> Optional[Dict]:
        """Get agent information"""
        return self.agents.get(agent_id)

    async def unregister_agent(self, agent_id: str) -> bool:
        """Remove agent from registry"""
        if agent_id in self.agents:
            capabilities = self.agents[agent_id]["capabilities"]
            for capability in capabilities:
                if capability in self.capabilities_index:
                    if agent_id in self.capabilities_index[capability]:
                        self.capabilities_index[capability].remove(agent_id)
            del self.agents[agent_id]
            return True
        return False


