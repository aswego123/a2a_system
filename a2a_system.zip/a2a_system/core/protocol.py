from typing import Dict, List, Optional, Any
from datetime import datetime
from dataclasses import dataclass, field, asdict
from enum import Enum


class MessageType(Enum):
    CAPABILITY_ANNOUNCEMENT = "capability_announcement"
    TASK_REQUEST = "task_request"
    TASK_RESPONSE = "task_response"
    STATUS_UPDATE = "status_update"


class TaskStatus(Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    PARTIAL = "partial"


@dataclass
class Capability:
    name: str
    description: str
    input_schema: Dict[str, Any] = field(default_factory=dict)
    cost_estimate: str = "low"
    avg_execution_time: str = "5s"


@dataclass
class Task:
    task_id: str
    task_type: str
    description: str
    priority: str = "medium"
    required_capabilities: List[str] = field(default_factory=list)
    input_data: Dict[str, Any] = field(default_factory=dict)
    parent_task_id: Optional[str] = None
    deadline: Optional[str] = None


@dataclass
class A2AMessage:
    protocol_version: str = "1.0"
    message_type: str = ""
    message_id: str = ""
    sender_agent_id: str = ""
    recipient_agent_id: str = ""
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass
class TaskRequest(A2AMessage):
    task: Optional[Task] = None
    context: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        self.message_type = MessageType.TASK_REQUEST.value


@dataclass
class TaskResponse(A2AMessage):
    in_response_to: str = ""
    status: str = ""
    result: Dict[str, Any] = field(default_factory=dict)
    error: Optional[Dict[str, str]] = None

    def __post_init__(self):
        self.message_type = MessageType.TASK_RESPONSE.value


