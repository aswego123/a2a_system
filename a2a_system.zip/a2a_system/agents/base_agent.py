import asyncio
import uuid
from typing import List, Dict, Optional, Any

from core.registry import AgentRegistry
from core.message_bus import A2AMessageBus


class A2AAgent:
    """Base class for A2A-enabled agents"""

    def __init__(
        self,
        agent_id: str,
        capabilities: List[str],
        registry: AgentRegistry,
        message_bus: A2AMessageBus
    ):
        self.agent_id = agent_id
        self.capabilities = capabilities
        self.registry = registry
        self.message_bus = message_bus
        self.message_queue = asyncio.Queue()
        self.running = False

    async def start(self):
        """Start the agent"""
        await self.registry.register_agent(
            self.agent_id,
            self.capabilities
        )
        await self.message_bus.subscribe(self.agent_id, self.message_queue)
        self.running = True
        asyncio.create_task(self._message_loop())

    async def stop(self):
        """Stop the agent"""
        self.running = False
        await self.registry.unregister_agent(self.agent_id)
        await self.message_bus.unsubscribe(self.agent_id)

    async def _message_loop(self):
        """Process incoming messages"""
        while self.running:
            try:
                message = await asyncio.wait_for(
                    self.message_queue.get(),
                    timeout=1.0
                )
                await self._handle_message(message)
            except asyncio.TimeoutError:
                continue

    async def _handle_message(self, message: Dict):
        """Handle incoming A2A message"""
        msg_type = message.get("message_type")

        if msg_type == "task_request":
            await self._handle_task_request(message)
        elif msg_type in ("task_response", "status_update"):
            # Consume without action; responses are completed by the sender via message_bus.complete_request
            return

    async def _handle_task_request(self, request: Dict):
        """Handle incoming task request"""
        task = request.get("task", {})
        task_id = task.get("task_id")
        sender = request.get("sender_agent_id")

        # Send status update
        await self._send_status_update(sender, task_id, "processing")

        try:
            # Execute task
            result = await self.execute_task(task)

            # Send success response
            await self._send_task_response(
                sender,
                request.get("message_id"),
                task_id,
                "completed",
                result
            )
        except Exception as e:
            # Send error response
            await self._send_task_response(
                sender,
                request.get("message_id"),
                task_id,
                "failed",
                {},
                error={"code": "execution_error", "message": str(e)}
            )

    async def execute_task(self, task: Dict) -> Dict[str, Any]:
        """Execute task - to be overridden by subclasses"""
        raise NotImplementedError("Subclasses must implement execute_task")

    async def send_task_to_agent(
        self,
        capability: str,
        task_data: Dict
    ) -> Optional[Dict]:
        """Send task request to another agent"""
        # Find capable agent
        agents = await self.registry.find_agents_by_capability(capability)
        if not agents:
            raise ValueError(f"No agent found with capability: {capability}")

        target_agent = agents[0]
        message_id = str(uuid.uuid4())

        message = {
            "protocol_version": "1.0",
            "message_type": "task_request",
            "message_id": message_id,
            "sender_agent_id": self.agent_id,
            "recipient_agent_id": target_agent,
            "task": task_data
        }

        return await self.message_bus.send_and_wait(message)

    async def _send_status_update(
        self,
        recipient: str,
        task_id: str,
        status: str
    ):
        """Send status update"""
        message = {
            "protocol_version": "1.0",
            "message_type": "status_update",
            "message_id": str(uuid.uuid4()),
            "sender_agent_id": self.agent_id,
            "recipient_agent_id": recipient,
            "task_id": task_id,
            "status": status
        }
        await self.message_bus.publish(message)

    async def _send_task_response(
        self,
        recipient: str,
        in_response_to: str,
        task_id: str,
        status: str,
        result: Dict,
        error: Optional[Dict] = None
    ):
        """Send task response"""
        response = {
            "protocol_version": "1.0",
            "message_type": "task_response",
            "message_id": str(uuid.uuid4()),
            "in_response_to": in_response_to,
            "sender_agent_id": self.agent_id,
            "recipient_agent_id": recipient,
            "status": status,
            "result": {
                "task_id": task_id,
                "output_data": result
            },
            "error": error
        }
        await self.message_bus.publish(response)
        self.message_bus.complete_request(in_response_to, response)

import asyncio
import uuid
from typing import List, Dict, Optional, Any


class A2AAgent:
    """Base class for A2A-enabled agents"""
    
    def __init__(
        self, 
        agent_id: str, 
        capabilities: List[str],
        registry: AgentRegistry,
        message_bus: A2AMessageBus
    ):
        self.agent_id = agent_id
        self.capabilities = capabilities
        self.registry = registry
        self.message_bus = message_bus
        self.message_queue = asyncio.Queue()
        self.running = False
    
    async def start(self):
        """Start the agent"""
        await self.registry.register_agent(
            self.agent_id, 
            self.capabilities
        )
        await self.message_bus.subscribe(self.agent_id, self.message_queue)
        self.running = True
        asyncio.create_task(self._message_loop())
    
    async def stop(self):
        """Stop the agent"""
        self.running = False
        await self.registry.unregister_agent(self.agent_id)
        await self.message_bus.unsubscribe(self.agent_id)
    
    async def _message_loop(self):
        """Process incoming messages"""
        while self.running:
            try:
                message = await asyncio.wait_for(
                    self.message_queue.get(), 
                    timeout=1.0
                )
                await self._handle_message(message)
            except asyncio.TimeoutError:
                continue
    
    async def _handle_message(self, message: Dict):
        """Handle incoming A2A message"""
        msg_type = message.get("message_type")
        
        if msg_type == "task_request":
            await self._handle_task_request(message)
    
    async def _handle_task_request(self, request: Dict):
        """Handle incoming task request"""
        task = request.get("task", {})
        task_id = task.get("task_id")
        sender = request.get("sender_agent_id")
        
        # Send status update
        await self._send_status_update(sender, task_id, "processing")
        
        try:
            # Execute task
            result = await self.execute_task(task)
            
            # Send success response
            await self._send_task_response(
                sender, 
                request.get("message_id"),
                task_id, 
                "completed", 
                result
            )
        except Exception as e:
            # Send error response
            await self._send_task_response(
                sender,
                request.get("message_id"),
                task_id,
                "failed",
                {},
                error={"code": "execution_error", "message": str(e)}
            )
    
    async def execute_task(self, task: Dict) -> Dict[str, Any]:
        """Execute task - to be overridden by subclasses"""
        raise NotImplementedError("Subclasses must implement execute_task")
    
    async def send_task_to_agent(
        self, 
        capability: str, 
        task_data: Dict
    ) -> Optional[Dict]:
        """Send task request to another agent"""
        # Find capable agent
        agents = await self.registry.find_agents_by_capability(capability)
        if not agents:
            raise ValueError(f"No agent found with capability: {capability}")
        
        target_agent = agents[0]
        message_id = str(uuid.uuid4())
        
        message = {
            "protocol_version": "1.0",
            "message_type": "task_request",
            "message_id": message_id,
            "sender_agent_id": self.agent_id,
            "recipient_agent_id": target_agent,
            "task": task_data
        }
        
        return await self.message_bus.send_and_wait(message)
    
    async def _send_status_update(
        self, 
        recipient: str, 
        task_id: str, 
        status: str
    ):
        """Send status update"""
        message = {
            "protocol_version": "1.0",
            "message_type": "status_update",
            "message_id": str(uuid.uuid4()),
            "sender_agent_id": self.agent_id,
            "recipient_agent_id": recipient,
            "task_id": task_id,
            "status": status
        }
        await self.message_bus.publish(message)
    
    async def _send_task_response(
        self, 
        recipient: str,
        in_response_to: str,
        task_id: str, 
        status: str, 
        result: Dict,
        error: Optional[Dict] = None
    ):
        """Send task response"""
        response = {
            "protocol_version": "1.0",
            "message_type": "task_response",
            "message_id": str(uuid.uuid4()),
            "in_response_to": in_response_to,
            "sender_agent_id": self.agent_id,
            "recipient_agent_id": recipient,
            "status": status,
            "result": {
                "task_id": task_id,
                "output_data": result
            },
            "error": error
        }
        await self.message_bus.publish(response)
        self.message_bus.complete_request(in_response_to, response)