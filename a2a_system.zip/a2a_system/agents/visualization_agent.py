import asyncio
from typing import Dict, Any

from agents.base_agent import A2AAgent
from core.registry import AgentRegistry
from core.message_bus import A2AMessageBus


class VisualizationAgent(A2AAgent):
    """Agent specialized in visualization"""

    def __init__(self, registry: AgentRegistry, message_bus: A2AMessageBus):
        super().__init__(
            agent_id="visualization-agent-001",
            capabilities=["visualization"],
            registry=registry,
            message_bus=message_bus
        )

    async def execute_task(self, task: Dict) -> Dict[str, Any]:
        """Create a simple visualization artifact"""
        data = task.get("input_data", {})
        insights = data.get("insights", [])

        await asyncio.sleep(0.5)

        # Produce a simple text-based visualization payload
        chart = {
            "type": "bar",
            "title": "Insights Confidence",
            "data": [{"label": insight, "value": data.get("confidence_score", 0)} for insight in insights]
        }

        return {
            "artifact_type": "chart_spec",
            "chart": chart
        }


