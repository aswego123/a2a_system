import asyncio
from typing import Dict, Any

from agents.base_agent import A2AAgent
from core.registry import AgentRegistry
from core.message_bus import A2AMessageBus


class DataAnalysisAgent(A2AAgent):
    """Agent specialized in data analysis"""

    def __init__(self, registry: AgentRegistry, message_bus: A2AMessageBus):
        super().__init__(
            agent_id="analysis-agent-001",
            capabilities=["data_analysis", "visualization", "statistics"],
            registry=registry,
            message_bus=message_bus
        )

    async def execute_task(self, task: Dict) -> Dict[str, Any]:
        """Execute analysis task"""
        input_data = task.get("input_data", {})

        # Simulate analysis
        await asyncio.sleep(1)

        analysis = {
            "analysis_type": "trend_analysis",
            "insights": [
                "Positive growth trend identified",
                "High market confidence"
            ],
            "confidence_score": 0.92,
            "processed_records": len(input_data.get("results", []))
        }

        # Identify need for visualization when we have insights
        if analysis["insights"]:
            try:
                viz_response = await self.send_task_to_agent(
                    "visualization",
                    {
                        "task_id": task.get("task_id", ""),
                        "task_type": "visualization",
                        "description": "Visualize analysis insights",
                        "input_data": {
                            "insights": analysis["insights"],
                            "confidence_score": analysis["confidence_score"]
                        }
                    }
                )
                if viz_response:
                    analysis["visualization"] = viz_response.get("result", {}).get("output_data", {})
            except Exception:
                # Visualization is optional; keep analysis even if viz delegation fails
                pass

        return analysis

