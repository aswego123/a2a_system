import asyncio
import uuid
from datetime import datetime
from typing import Dict, Any

from agents.base_agent import A2AAgent
from core.registry import AgentRegistry
from core.message_bus import A2AMessageBus


class ResearchAgent(A2AAgent):
    """Agent specialized in research and web search"""

    def __init__(self, registry: AgentRegistry, message_bus: A2AMessageBus):
        super().__init__(
            agent_id="research-agent-001",
            capabilities=["web_search", "research", "summarization"],
            registry=registry,
            message_bus=message_bus
        )

    async def execute_task(self, task: Dict) -> Dict[str, Any]:
        """Execute research task"""
        description = task.get("description", "")
        print(f"\n[{self.agent_id}] 🔍 Starting research: '{description}'")

        # Simulate research with realistic delay
        await asyncio.sleep(2)

        research_data = {
            "query": description,
            "sources_searched": 5,
            "results": [
                {
                    "title": "AI Trends Report 2025: Enterprise Adoption Accelerates",
                    "source": "TechResearch.com",
                    "summary": "AI adoption in enterprises grew 340% YoY, with GenAI leading adoption",
                    "relevance_score": 0.95
                },
                {
                    "title": "Market Analysis: AI Investment Reaches $200B",
                    "source": "MarketWatch",
                    "summary": "Global AI market shows sustained growth, dominated by cloud AI services",
                    "relevance_score": 0.88
                },
                {
                    "title": "Industry Survey: AI Implementation Challenges",
                    "source": "Forbes Tech",
                    "summary": "85% of companies cite data quality as primary AI adoption barrier",
                    "relevance_score": 0.82
                }
            ],
            "search_time": "2.1s",
            "timestamp": datetime.now().isoformat()
        }

        print(f"[{self.agent_id}] ✅ Research complete: Found {len(research_data['results'])} relevant sources")

        # Check if analysis is needed
        if "analyze" in description.lower():
            print(f"[{self.agent_id}] 🤝 Delegating analysis to specialist agent...")

            try:
                # Delegate to analysis agent via A2A
                analysis_result = await self.send_task_to_agent(
                    "data_analysis",
                    {
                        "task_id": str(uuid.uuid4()),
                        "task_type": "data_analysis",
                        "description": "Analyze research findings and extract key trends",
                        "input_data": research_data
                    }
                )

                if analysis_result:
                    research_data["analysis"] = analysis_result.get("result", {}).get("output_data", {})
                    print(f"[{self.agent_id}] 📊 Analysis received and integrated")
            except Exception as e:
                print(f"[{self.agent_id}] ⚠️ Analysis delegation failed: {e}")

        return research_data


