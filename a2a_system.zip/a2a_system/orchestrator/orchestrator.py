import uuid
from typing import Dict

from core.registry import AgentRegistry
from core.message_bus import A2AMessageBus


class A2AOrchestrator:
    """Orchestrator for managing user requests and agent coordination"""

    def __init__(self, registry: AgentRegistry, message_bus: A2AMessageBus):
        self.registry = registry
        self.message_bus = message_bus

    async def handle_user_request(self, user_input: str) -> Dict:
        """Handle user request and route to appropriate agent"""
        # Determine required capability
        capability = self._determine_capability(user_input)

        # Find suitable agent
        agent_ids = await self.registry.find_agents_by_capability(capability)
        if not agent_ids:
            return {"error": f"No agent found for capability: {capability}"}

        primary_agent = agent_ids[0]
        message_id = str(uuid.uuid4())

        # Create task request
        task_request = {
            "protocol_version": "1.0",
            "message_type": "task_request",
            "message_id": message_id,
            "sender_agent_id": "orchestrator",
            "recipient_agent_id": primary_agent,
            "task": {
                "task_id": str(uuid.uuid4()),
                "task_type": capability,
                "description": user_input,
                "priority": "high"
            }
        }

        # Send and wait for result
        try:
            result = await self.message_bus.send_and_wait(
                task_request,
                timeout=60
            )
            return result
        except TimeoutError as e:
            return {"error": str(e)}

    def _determine_capability(self, user_input: str) -> str:
        """Determine required capability from user input"""
        keywords = {
            "research": ["research", "search", "find", "investigate"],
            "data_analysis": ["analyze", "analysis", "statistics", "trends"],
            "web_search": ["web", "online", "internet", "search"]
        }

        user_lower = user_input.lower()
        for capability, terms in keywords.items():
            if any(term in user_lower for term in terms):
                return capability

        return "web_search"  # Default

import uuid


class A2AOrchestrator:
    """Orchestrator for managing user requests and agent coordination"""
    
    def __init__(self, registry: AgentRegistry, message_bus: A2AMessageBus):
        self.registry = registry
        self.message_bus = message_bus
    
    async def handle_user_request(self, user_input: str) -> Dict:
        """Handle user request and route to appropriate agent"""
        # Determine required capability
        capability = self._determine_capability(user_input)
        
        # Find suitable agent
        agent_ids = await self.registry.find_agents_by_capability(capability)
        if not agent_ids:
            return {"error": f"No agent found for capability: {capability}"}
        
        primary_agent = agent_ids[0]
        message_id = str(uuid.uuid4())
        
        # Create task request
        task_request = {
            "protocol_version": "1.0",
            "message_type": "task_request",
            "message_id": message_id,
            "sender_agent_id": "orchestrator",
            "recipient_agent_id": primary_agent,
            "task": {
                "task_id": str(uuid.uuid4()),
                "task_type": capability,
                "description": user_input,
                "priority": "high"
            }
        }
        
        # Send and wait for result
        try:
            result = await self.message_bus.send_and_wait(
                task_request, 
                timeout=60
            )
            return result
        except TimeoutError as e:
            return {"error": str(e)}
    
    def _determine_capability(self, user_input: str) -> str:
        """Determine required capability from user input"""
        keywords = {
            "research": ["research", "search", "find", "investigate"],
            "data_analysis": ["analyze", "analysis", "statistics", "trends"],
            "web_search": ["web", "online", "internet", "search"]
        }
        
        user_lower = user_input.lower()
        for capability, terms in keywords.items():
            if any(term in user_lower for term in terms):
                return capability
        
        return "web_search"  # Default